class MovieName{
  String name;
  String image;

  MovieName(this.name, this.image);
}