class Constants {
  static const double textFieldBorder = 15.0;
  static const double drawerFieldBorder = 20.0;
  static final double buttonHeight = 60;
  static const double textFieldPadding = 20.0;
}