class Routes {
  static const String SplashRoute = 'splash';
  static const String DashBoard = 'dashboard';
  static const String Home = 'home';
  static const String FindMovie = 'find Movie';
  static const String FindTv = 'find Tv';
  static const String FindKids = 'find Kids';
  static const String FindAmazon = 'find Amazon';
  static const String AutoDownloads = 'auto downloads';
  static const String WhatsDownloads = 'Whats Downloads';
  static const String CreateProfile = 'Create Profile';
  static const String ManageProfile = 'manage Profile';
  static const String Setting = 'setting';
  static const String StreamDownload = 'stream Download';
  static const String StreamingQuality = 'streaming Quality';
  static const String DownloadQuality = 'download Quality';
  static const String CastData = 'cast Data';
  static const String Notification = 'notification';
  static const String ParentalControls = 'parental Controls';
  static const String ContactUs = 'contact Us';
  static const String AboutLegal = 'aboutLegal';
















}
